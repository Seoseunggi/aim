import { React, useState, useEffect } from "react";
import axios from "axios";
//import styled from "styled-components";
import { useNavigate } from "react-router-dom";

import Table from "react-bootstrap/Table";
import Button from "react-bootstrap/Button";
import Spinner from "react-bootstrap/Spinner";
import Navybar from "../components/Navybar";

function Board_list() {
  const navigate = useNavigate();
  //제목설정
  const title = "게시판 리스트";

  //userState
  //로딩체크
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);

  //styled 컴포넌트
  // const SDatePicker = styled(Calendar)`
  //   background-color: colors.$BG_COLOR;
  //   margin-top: 1.5rem;
  //   width: 300px;
  //   height: 42px;
  //   box-sizing: border-box;
  //   padding: 8px 20px;
  //   border-radius: 4px;
  //   border: 1px solid #ccc;
  //   font-size: 12px;
  // `;

  //기간조회 버튼 클릭
  const onClickBoard = async () => {
    //axios방식
    axios
      .post("http://192.168.4.76:5001/board_list", {})
      .then(function (res) {
        console.log(res);
        setList(res.data.recordset);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const viewContent = (item) => {
    navigate(`/board_view/${item.no}`); //뷰로 이동
  };

  const onClickWrite = () => {
    navigate("/board_write"); //글쓰기로 이동
  };

  useEffect(() => {
    //페이지 접속시, 기본 기간조회 동작 1번
    onClickBoard();
  }, []);

  return (
    <div>
      <Navybar title={title} />

      {loading ? (
        <Button variant="primary" disabled>
          <Spinner
            as="span"
            animation="border"
            size="sm"
            role="status"
            aria-hidden="true"
          />
          <span className="visually-hidden">Loading...</span>
        </Button>
      ) : null}

      <Table hover>
        <thead>
          <tr>
            <th scope="col">번호</th>
            <th scope="col">글쓴이</th>
            <th scope="col">제목</th>
            <th scope="col">등록일</th>
            <th scope="col">추천</th>
            <th scope="col">조회</th>
          </tr>
        </thead>
        <tbody>
          {list.map((item) => (
            <tr onClick={() => viewContent(item)}>
              <th scope="row">{item.no}</th>
              <td>{item.name}</td>
              <td>{item.title}</td>
              <td>
                {/* let Today = "20210101"
              Today.substr(0, 4) + '-' + Today.substr(4, 2) + '-' + Today.substr(6, 2); */}
                {/* {item.wdate.replace(/(\d{4})(\d{2})(\d{2})/g, "$1-$2-$3")} */}
                {new Date(item.wdate).toLocaleString()}
              </td>
              <td>{item.up}</td>
              <td>{item.count}</td>
            </tr>
          ))}
        </tbody>
      </Table>
      <div>
        <Button variant="secondary" type="button" onClick={onClickWrite}>
          글쓰기
        </Button>{" "}
      </div>
    </div>
  );
}

export default Board_list;
