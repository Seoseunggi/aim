import { React, useState, useEffect } from "react";
import axios from "axios";
//import styled from "styled-components";
import { useNavigate, useParams } from "react-router-dom";

import Button from "react-bootstrap/Button";
import Spinner from "react-bootstrap/Spinner";
import Navybar from "../components/Navybar";
import * as DOMPurify from "dompurify";

function Board_view() {
  const { id } = useParams();

  const navigate = useNavigate();
  //제목설정
  const title = "내용 보기";

  //userState
  //로딩체크
  const [loading, setLoading] = useState(true);
  const [list, setList] = useState([]);

  //styled 컴포넌트
  // const SDatePicker = styled(Calendar)`
  //   background-color: colors.$BG_COLOR;
  //   margin-top: 1.5rem;
  //   width: 300px;
  //   height: 42px;
  //   box-sizing: border-box;
  //   padding: 8px 20px;
  //   border-radius: 4px;
  //   border: 1px solid #ccc;
  //   font-size: 12px;
  // `;

  //기간조회 버튼 클릭
  const onClickBoard = async () => {
    //axios방식
    axios
      .post("http://192.168.4.76:5001/board_view", {
        board_id: `${id}`,
      })
      .then(function (res) {
        console.log(res);
        setList(res.data.recordset);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const onClickList = () => {
    navigate("/board_list"); //글쓰기로 이동
  };

  useEffect(() => {
    //페이지 접속시, 기본 기간조회 동작 1번
    onClickBoard();
  }, []);

  return (
    <div>
      <Navybar title={title} />
      {loading ? (
        <Button variant="primary" disabled>
          <Spinner
            as="span"
            animation="border"
            size="sm"
            role="status"
            aria-hidden="true"
          />
          <span className="visually-hidden">Loading...</span>
        </Button>
      ) : null}
      <div>
        제목: {list[0]?.title}
        {list[0]?.contents && (
          <div
            style={{
              width: "60vw",
              whiteSpace: "normal",
            }}
            dangerouslySetInnerHTML={{
              __html: DOMPurify.sanitize(String(list[0]?.contents)),
            }}
          />
        )}
      </div>
      <div>
        <Button variant="secondary" type="button" onClick={onClickList}>
          리스트로
        </Button>{" "}
      </div>
    </div>
  );
}

export default Board_view;
