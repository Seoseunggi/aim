import { React, useState, useEffect, useRef, useMemo } from "react";
import axios from "axios";
//import styled from "styled-components";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Navybar from "../components/Navybar";
import { getItemWithExpireTime } from "../Login/Auth";
import { useNavigate } from "react-router-dom";

import ReactQuill from "react-quill";
import Quill from "quill";
import "react-quill/dist/quill.snow.css";
import ImageResize from "@looop/quill-image-resize-module-react"; //새로받은것
Quill.register("modules/ImageResize", ImageResize);

//quill 설정
const formats = [
  "header",
  "font",
  "size",
  "bold",
  "italic",
  "underline",
  "strike",
  "align",
  "blockquote",
  "list",
  "bullet",
  "indent",
  "background",
  "color",
  "link",
  "image",
  "video",
  "width",
];

function Board_write() {
  const navigate = useNavigate();
  const userInfo = JSON.parse(getItemWithExpireTime("userinfo"));

  //제목설정
  const title = "게시판 글쓰기";

  //userState
  const [title1, setTitle1] = useState("");
  const [content, setContent] = useState("");

  const quillRef = useRef(null); //에디터 접근을 위한 ref return

  const imageHandler = async () => {
    const input = document.createElement("input");
    input.setAttribute("type", "file");
    input.setAttribute("accept", "image/*");
    input.click();

    input.addEventListener("change", async () => {
      //이미지를 담아 전송할 file을 만든다
      const file = input.files?.[0];
      try {
        const formData = new FormData();
        formData.append("image", file);
        const res = await axios.post("http://192.168.4.76:5001/img", formData);
        //이미지 업로드 후, 이미지 url 가져오기
        const url = res?.data?.url;
        console.log("server image: " + url);

        if (quillRef.current) {
          console.log("quillRef start");
          const editor = quillRef.current.getEditor();
          const range = editor.getSelection();

          editor.insertEmbed(range.index, "image", `${url}`);
          editor.setSelection(range.index + 1);
        }
      } catch (error) {
        console.log(error);
      }
    });
  };

  const modules = useMemo(
    () => ({
      toolbar: {
        container: [
          [{ header: [1, 2, 3, 4, 5, 6, false] }],
          ["bold", "italic", "underline", "strike"],
          [
            { list: "ordered" },
            { list: "bullet" },
            { indent: "-1" },
            { indent: "+1" },
          ],
          ["image", "link"],
          [
            {
              color: ["#000000", "#e60000", "#ff9900", "#ffff00"],
            },
          ],
        ],
        handlers: {
          image: imageHandler,
        },
      },

      /* 추가된 코드 */
      ImageResize: {
        modules: ["Resize"],
      },
    }),
    []
  );

  //기간조회 버튼 클릭
  const onClickSend = async () => {
    //axios방식
    axios
      .post("http://192.168.4.76:5001/board_write", {
        name: userInfo.name,
        title: title1,
        content: content,
      })
      .then(function (res) {
        console.log(res.data.result);
        navigate("/board_list");
      })
      .catch((err) => {
        console.log(err);
      });
  };
  const onClickCancel = () => {
    navigate("/board_list"); //글쓰기로 이동
  };

  const handleInputTitle = (e) => {
    setTitle1(e.target.value); // react input 입력값 가져오기.
  };

  // const handleInputContent = (e) => {
  //   setContent(e.target.value);
  // };

  useEffect(() => {
    //페이지 접속시, 기본 동작 1번
  }, []);

  return (
    <div>
      <Navybar title={title} />

      <Form>
        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
          <Form.Label>제목</Form.Label>
          <Form.Control
            type="email"
            placeholder="제목을 입력해주세요."
            value={title1}
            onChange={handleInputTitle}
          />
        </Form.Group>
        {/* <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
          <Form.Label>내용</Form.Label>
          <Form.Control
            as="textarea"
            rows={3}
            value={content}
            onChange={handleInputContent}
          />
        </Form.Group> */}
      </Form>
      <div>
        {"내용"}
        <ReactQuill
          ref={quillRef}
          modules={modules}
          formats={formats}
          //value={content}
          onChange={setContent}
          style={{ height: "460px" }}
          theme="snow"
          placeholder="내용을 입력해주세요."
        />
      </div>
      <div style={{ marginTop: "80px" }}>
        <div>
          <Button variant="secondary" type="button" onClick={onClickCancel}>
            취소
          </Button>{" "}
        </div>
        <div>
          <Button variant="secondary" type="button" onClick={onClickSend}>
            작성완료
          </Button>{" "}
        </div>
      </div>
    </div>
  );
}

export default Board_write;
